//
//  SettingsView.swift
//  perfil-SintoCheck
//
//  Created by Andrea Badillo on 10/16/23.
//

import SwiftUI

struct SettingsView: View {
    var body: some View {
        Text("Hola es la parte de Alexa")
    }
}

#Preview {
    SettingsView()
}
