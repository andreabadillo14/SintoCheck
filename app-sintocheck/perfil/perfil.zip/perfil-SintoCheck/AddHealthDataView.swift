//
//  AddHealthDataView.swift
//  perfil-SintoCheck
//
//  Created by Andrea Badillo on 10/16/23.
//

import SwiftUI

struct AddHealthDataView: View {
    var body: some View {
        Text("Hola es la parte de diego")
    }
}

#Preview {
    AddHealthDataView()
}
