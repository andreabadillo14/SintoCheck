//
//  perfil_SintoCheckApp.swift
//  perfil-SintoCheck
//
//  Created by Andrea Badillo on 10/16/23.
//

import SwiftUI

@main
struct perfil_SintoCheckApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
